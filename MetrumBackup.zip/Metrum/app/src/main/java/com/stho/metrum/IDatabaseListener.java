package com.stho.metrum;

public interface IDatabaseListener {

    void onNotifyDatabaseCreation();
}
