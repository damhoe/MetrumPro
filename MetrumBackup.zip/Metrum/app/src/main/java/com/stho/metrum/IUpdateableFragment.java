package com.stho.metrum;

public interface IUpdateableFragment {
    void updateViewModel(ViewModel viewModel);
}
