package com.stho.metrum;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Locale;

public class StandardModeFragment extends Fragment implements View.OnClickListener, IUpdateableFragment {

    private class ViewHolder {
        ImageButton button;
        TextView tempo;
        TextView frequency;
        TextView track;
        TextView dance;
        TextView lambOne;
        TextView lambTwo;
        TextView lambThree;
        TextView lambFour;
        ViewPager viewPager;
        RelativeLayout mainLayout;
    }

    private ViewHolder viewHolder = new ViewHolder();
    private MainActivity mainActivity;
    private ViewModel viewModel;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.standard_mode_fragment, container, false);
        mainActivity = (MainActivity) getActivity();


        viewHolder.button = (ImageButton) rootView.findViewById(R.id.btn_state_change);
        viewHolder.button.setOnClickListener(this);
        viewHolder.button.setImageResource(android.R.drawable.ic_media_play);
        viewHolder.tempo = rootView.findViewById(R.id.tempo);

        viewHolder.frequency = rootView.findViewById(R.id.frequency);
        viewHolder.frequency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mainActivity.defineFrequency();
            }
        });
        viewHolder.viewPager = rootView.findViewById(R.id.pager);
        viewHolder.viewPager.setAdapter(new MetrumPagerAdapter(this.getActivity()));
        viewHolder.mainLayout = rootView.findViewById(R.id.main_layout);
        viewHolder.track = rootView.findViewById(R.id.track);
        viewHolder.dance = rootView.findViewById(R.id.dance);
        //viewHolder.lambOne = rootView.findViewById(R.id.lamp_one);
        //viewHolder.lambTwo = rootView.findViewById(R.id.lamp_two);
        //viewHolder.lambThree = rootView.findViewById(R.id.lamp_three);
        //viewHolder.lambFour = rootView.findViewById(R.id.lamp_four);

        mainActivity.updateData();

        return rootView;
    }

    @Override
    public void updateViewModel(ViewModel viewModel) {

        this.viewModel = viewModel;

        //viewHolder.tempo.setText(Tempi.getNameByBeats(viewModel.getBeatsPerMinute()));
        //viewHolder.frequency.setText(String.format(Locale.ENGLISH, "%d", viewModel.getBeatsPerMinute()));
        if (viewModel.getRunState()) {
            //viewHolder.button.setImageResource(android.R.drawable.ic_media_pause);
        } else if (!viewModel.getRunState()) {
            //viewHolder.button.setImageResource(android.R.drawable.ic_media_play);
        }
    }

    @Override
    public void onClick(View v) {
        if (viewModel.getRunState()) {
            mainActivity.onNotifyPlayerStateChanging(false);
        }
        else if (!viewModel.getRunState()) {
            mainActivity.onNotifyPlayerStateChanging(true);
        }
    }
}
